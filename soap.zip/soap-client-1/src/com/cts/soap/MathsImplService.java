/**
 * MathsImplService.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.cts.soap;

public interface MathsImplService extends javax.xml.rpc.Service {
    public java.lang.String getMathsImplAddress();

    public com.cts.soap.MathsImpl getMathsImpl() throws javax.xml.rpc.ServiceException;

    public com.cts.soap.MathsImpl getMathsImpl(java.net.URL portAddress) throws javax.xml.rpc.ServiceException;
}
