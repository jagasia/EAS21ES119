package com.cts.soap;

public class MathsImplProxy implements com.cts.soap.MathsImpl {
  private String _endpoint = null;
  private com.cts.soap.MathsImpl mathsImpl = null;
  
  public MathsImplProxy() {
    _initMathsImplProxy();
  }
  
  public MathsImplProxy(String endpoint) {
    _endpoint = endpoint;
    _initMathsImplProxy();
  }
  
  private void _initMathsImplProxy() {
    try {
      mathsImpl = (new com.cts.soap.MathsImplServiceLocator()).getMathsImpl();
      if (mathsImpl != null) {
        if (_endpoint != null)
          ((javax.xml.rpc.Stub)mathsImpl)._setProperty("javax.xml.rpc.service.endpoint.address", _endpoint);
        else
          _endpoint = (String)((javax.xml.rpc.Stub)mathsImpl)._getProperty("javax.xml.rpc.service.endpoint.address");
      }
      
    }
    catch (javax.xml.rpc.ServiceException serviceException) {}
  }
  
  public String getEndpoint() {
    return _endpoint;
  }
  
  public void setEndpoint(String endpoint) {
    _endpoint = endpoint;
    if (mathsImpl != null)
      ((javax.xml.rpc.Stub)mathsImpl)._setProperty("javax.xml.rpc.service.endpoint.address", _endpoint);
    
  }
  
  public com.cts.soap.MathsImpl getMathsImpl() {
    if (mathsImpl == null)
      _initMathsImplProxy();
    return mathsImpl;
  }
  
  public int product(int i, int j) throws java.rmi.RemoteException{
    if (mathsImpl == null)
      _initMathsImplProxy();
    return mathsImpl.product(i, j);
  }
  
  public int sum(int i, int j) throws java.rmi.RemoteException{
    if (mathsImpl == null)
      _initMathsImplProxy();
    return mathsImpl.sum(i, j);
  }
  
  
}