package com.cts.soap;

import java.rmi.RemoteException;

public class Main {

	public static void main(String[] args) throws RemoteException {
		//access web service using proxy
		
		MathsImplProxy proxy=new MathsImplProxy();
		System.out.println(proxy.sum(5, 10));
	}

}
