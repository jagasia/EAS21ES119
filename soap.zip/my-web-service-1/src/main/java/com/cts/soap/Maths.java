package com.cts.soap;

public interface Maths {

	int sum(int i, int j);

	int product(int i, int j);

}