package com.cts.soap;

public class MathsImpl implements Maths {
	@Override
	public int sum(int i, int j)
	{
		return i+j;
	}
	@Override
	public int product(int i, int j)
	{
		return i*j;
	}
}
