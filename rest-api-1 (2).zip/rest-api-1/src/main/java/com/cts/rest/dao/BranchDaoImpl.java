package com.cts.rest.dao;

import java.sql.Connection;
import java.sql.Driver;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.cts.rest.entity.Branch;

public class BranchDaoImpl implements BranchDao {
	private Connection getConnection() throws SQLException
	{
		Driver driver=new com.mysql.jdbc.Driver();
		return DriverManager.getConnection("jdbc:mysql://localhost:3306/es119","root","");
	}
	
	@Override
	public int create(Branch branch) throws SQLException {
		Connection con = getConnection();
		PreparedStatement st = con.prepareStatement("INSERT INTO Branch VALUES (?,?,?)");
		st.setString(1, branch.getBid());
		st.setString(2, branch.getBname());
		st.setString(3, branch.getBcity());
		int no=st.executeUpdate();
		con.close();
		return no;
	}
	@Override
	public List<Branch> read() throws SQLException {
		Connection con = getConnection();
		Statement st = con.createStatement();
		ResultSet rs = st.executeQuery("SELECT * FROM Branch");
		List<Branch> branchList=new ArrayList<Branch>();
		while(rs.next())
		{
			//every iteration gives one row. Each row becomes on object of Branch
			Branch branch=new Branch(rs.getString(1), rs.getString(2), rs.getString(3));
			branchList.add(branch);
		}
		con.close();
		return branchList;
	}
	@Override
	public Branch read(String bid) throws SQLException {
		Connection con = getConnection();
		PreparedStatement st = con.prepareStatement("SELECT * FROM Branch WHERE bid=?");
		st.setString(1, bid);
		ResultSet rs = st.executeQuery();
		Branch branch=null;
		if(rs.next())
		{
			branch=new Branch(rs.getString(1), rs.getString(2), rs.getString(3));
		}
		con.close();
		return branch;
	}
	@Override
	public int update(Branch branch) throws SQLException {
		Connection con = getConnection();
		PreparedStatement st = con.prepareStatement("UPDATE Branch SET bname=?, bcity=? WHERE bid=?");
		
		st.setString(1, branch.getBname());
		st.setString(2, branch.getBcity());
		st.setString(3, branch.getBid());
		
		int no=st.executeUpdate();
		con.close();
		return no;
	}
	@Override
	public int delete(String bid) throws SQLException {
		Connection con = getConnection();
		PreparedStatement st = con.prepareStatement("DELETE FROM Branch WHERE bid=?");
		st.setString(1, bid);
		int no=st.executeUpdate();
		con.close();
		return no;
	}
	
}
