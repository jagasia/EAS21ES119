package com.cts.rest.dao;

import java.sql.SQLException;
import java.util.List;

import com.cts.rest.entity.Branch;

public interface BranchDao {

	int create(Branch branch) throws SQLException;

	List<Branch> read() throws SQLException;

	Branch read(String bid) throws SQLException;

	int update(Branch branch) throws SQLException;

	int delete(String bid) throws SQLException;

}