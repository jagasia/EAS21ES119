package com.cts.rest;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Response;

@Path("/")
public class MyController {
	@GET
	@Path("/hello")
	@Produces("text/xml")
	public Response home()
	{
		return Response.status(200).entity("<b>Hello world</b>").build();
	}
	
	@GET
	@Path("/hi")
	@Produces("text/json")
	public String hi()
	{
		return "Hello world this is hi method";
	}
	
	@GET
	@Path("/employee")
	@Produces("text/json")
	public Employee getEmployee()
	{
		return new Employee(1L, "Rama","Krishna");
	}
}
